

function checkPalindrome() {
    let input = document.getElementById('inputText').value;
    //henter input fra inputText
    let lower = input.toLowerCase().replace(/[^a-z0-9]/g, '')
    //gjør om til lowercase slik at det ikke er forskjell på store og små bokstaver
    let reversed = lower.split('').reverse().join('') 
    //reverserer strengen
    //enderer spanen
    let span = document.getElementById('output')
    //if setning som sier at hvis de er like endre til Palindrome, alt annet blir not a palindrome
     if(reversed === lower){
       span.innerHTML = "Palindrome"  
       span.innerText = "Palindrome"   
     }else{
        span.innerHTML = "Not a Palindrome"
        span.innerText = "Not a Palindrome"
     }

}

