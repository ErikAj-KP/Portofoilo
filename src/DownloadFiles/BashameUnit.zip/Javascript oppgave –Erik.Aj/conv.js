//konvertering og venting på at nettsiden er lastet 
document.addEventListener('DOMContentLoaded', () => {
    const liter = document.getElementById('eu-liter');
    const tablespoons = document.getElementById('eu-tablespoons');
    const cups = document.getElementById('us-cups');
    const gallons = document.getElementById('us-gallons');
    const ounces = document.getElementById('us-ounces');

    //resetter alt med escape key
    document.addEventListener('keydown', (e) => {  //listener som venter på keydown e som er gitt escape key
        if (e.key === 'Escape') {
            liter.value = '';   //resetter/ setter alt input til tom string verdi
            tablespoons.value = '';
            cups.value = '';
            gallons.value = '';
            ounces.value = '';
        }
    });

    // passer på at ingen bokstaver koommer inn 
    const inputs = [liter, tablespoons, cups, gallons, ounces];
    inputs.forEach(input => {
        input.addEventListener('keypress', (e) => {
            if (!/[\d.]/.test(e.key) && e.key !== 'Enter') {
                e.preventDefault();
            }
        });
    });


    //tar input verdier og gjør om til andre enheter
    let liter2 = document.getElementById('eu-liter');
    let tablespoons2 = document.getElementById('eu-tablespoons');
    let cups2 = document.getElementById('us-cups');
    let gallons2 = document.getElementById('us-gallons');
    let ounces2 = document.getElementById('us-ounces');


    //lager en event listener for hver input verdi og kjører funksjonene hvis den ser endring
    liter2.addEventListener('input', LiterConverter)
    tablespoons2.addEventListener('input', TablespoonsConverter);
    cups2.addEventListener('input', CupsConverter);
    gallons2.addEventListener('input', GallonsConverter);
    ounces2.addEventListener('input', OuncesConverter);

    //toFixed på svart tekst for å få 2 desimaler
    
    //funksjon som gjør om fra liter til andre enheter og bruker to fixed for å få 2 desimaler
    function LiterConverter(value) {
        document.getElementById('eu-tablespoons').value = (liter2.value * 67.628).toFixed(2);
        document.getElementById('us-cups').value = (liter2.value * 4.22675).toFixed(2);
        document.getElementById('us-gallons').value = (liter2.value * 0.264172).toFixed(2);
        document.getElementById('us-ounces').value = (liter2.value * 33.814).toFixed(2);
    }
    //same som liter bare for tablespoons
    function TablespoonsConverter(value) {
        document.getElementById('eu-liter').value = (tablespoons2.value * 0.014438).toFixed(2);
        document.getElementById('us-cups').value = (tablespoons2.value * 0.0625).toFixed(2);
        document.getElementById('us-gallons').value = (tablespoons2.value * 0.00390625).toFixed(2);
        document.getElementById('us-ounces').value = (tablespoons2.value * 0.5).toFixed(2);
    }   
    //same som liter bare for cups
    function CupsConverter(value) {
        document.getElementById('eu-liter').value = (cups2.value * 0.236588).toFixed(2);
        document.getElementById('eu-tablespoons').value = (cups2.value * 16).toFixed(2);
        document.getElementById('us-gallons').value = (cups2.value * 0.0625).toFixed(2);
        document.getElementById('us-ounces').value = (cups2.value * 8).toFixed(2);
    }
    //same som liter bare for gallons
    function GallonsConverter(value) {
        document.getElementById('eu-liter').value = (gallons2.value * 3.78541).toFixed(2);
        document.getElementById('eu-tablespoons').value = (gallons2.value * 676.28).toFixed(2);
        document.getElementById('us-cups').value = (gallons2.value * 16).toFixed(2);
        document.getElementById('us-ounces').value = (gallons2.value * 128).toFixed(2);
    }
    //same some liter bare for ounces
    function OuncesConverter(value) {
        document.getElementById('eu-liter').value = (ounces2.value * 0.0295735).toFixed(2);
        document.getElementById('eu-tablespoons').value = (ounces2.value * 0.5).toFixed(2);
        document.getElementById('us-cups').value = (ounces2.value * 0.125).toFixed(2);
        document.getElementById('us-gallons').value = (ounces2.value * 0.0078125).toFixed(2);
    }
   




    
});
