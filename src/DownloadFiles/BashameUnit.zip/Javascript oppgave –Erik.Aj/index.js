//animasjon på knappene
document.querySelectorAll('.btn').forEach(button => {
    button.addEventListener('mouseover', () => {
        button.style.transition = 'all 0.3s ease';
    });
});
