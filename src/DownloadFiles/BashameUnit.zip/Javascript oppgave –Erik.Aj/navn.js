// Venter på at DOM/hele nettsiden er lastet inn
document.addEventListener('DOMContentLoaded', function() {
    // Henter referanser fra htmlen
    const container = document.getElementById('inputdiv');
    const addButton = document.getElementById('addboxbutton');
    const removeButton = document.getElementById('removexboxbutton');
    
    // Legger til klikk listenenr til knappen for å lage ny boks
    addButton.addEventListener('click', function() {
        //lage ny boks 
        const newInput = document.createElement('input');
        newInput.type = 'text';
        newInput.className = 'inputbox newbox';
        newInput.placeholder = 'Enter text...';
        
        //listener for å se etter endringer
        newInput.addEventListener('input', adder);
        
        // Legger til den nye boksen i containeren
        container.appendChild(newInput);
        
        // delay til animasjonene
        setTimeout(() => {
            newInput.classList.add('visible');
        }, 10);
    });

    // input listener til den første boksen
    document.getElementById('inputText2').addEventListener('input', adder);
    
    // remove knapp listener
    removeButton.addEventListener('click', function() {
        const inputs = container.getElementsByTagName('input');
        if (inputs.length > 1) { 
            const lastInput = inputs[inputs.length - 1];
            // Start animasjonen
            lastInput.classList.remove('visible');
            
            // fjerne element etter animasjon med cooldown
            setTimeout(() => {
                container.removeChild(lastInput);
            }, 300); 
        }
    });
});

// refferanser til htmlen
let input = document.getElementById('inputText2');
let output = document.getElementById('output');
let array = [];  
let addbutton = document.getElementById('addboxbutton');
let randomizebutton = document.getElementById('randomizebutton');
let removebutton = document.getElementById('removexboxbutton');

// listener til add knappen
addbutton.addEventListener('click', adder);
    
// funksjon for å samle inn og lagre alle input verdier
function adder() {   
    const inputs = document.getElementsByClassName('inputbox');
    // konverter input til array, får verdiene og filtrerer ut uten ting i det
    array = Array.from(inputs).map(input => input.value).filter(value => value.trim() !== '');
    console.log(array);
}

// listener til remove knappen
removebutton.addEventListener('click', remover);

// funksjon for å fjerne elementer fra array
function remover() {
    // oppdaterer array basert på imput
    const inputs = document.getElementsByClassName('inputbox');
    array = Array.from(inputs).map(input => input.value).filter(value => value.trim() !== '');
    
    // bare fjerne fra array hvis det er mer enn en input
    if (array.length > 1) {
        array.pop();
        output.textContent = array.join(', ');
    }
    console.log(array);
}
//listener til randomize knappene, 2 fordi hvis det er under 400px wide så bytter knappen 
randomizebutton.addEventListener('click', randomize);
randomizebutton2.addEventListener('click', randomize);

//randomiserer array
function randomize() {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    output.textContent = array.join(', ');
    console.log(array);
}