var tall1 = 0;
var metal = document.getElementById("clang");

function Clickrice() {
    // Increment and display count
    tall1 += 1;
    document.getElementById("tall").innerHTML = tall1;
    
    // Play the audio
    metal.currentTime = 0; // Reset audio to start
    metal.play().catch(function(error) {
        console.error("Audio playback failed:", error);
    });

    // Generate random x and y positions within the container
    const container = document.getElementById("imageContainer");
    const maxWidth = container.clientWidth - 50; // Adjust for image width
    const maxHeight = container.clientHeight - 50; // Adjust for image height
    const randomX = Math.floor(Math.random() * maxWidth);
    const randomY = Math.floor(Math.random() * maxHeight);

    // Create a new image element
    const img = document.createElement("img");
    img.src = "artworks-iOJGvkVM5t4oeeOX-1GUbBA-t500x500.jpg"; // Replace with the actual image URL
    img.classList.add("random-image");

    // Set the random position
    img.style.left = `${randomX}px`;
    img.style.top = `${randomY}px`;

    // Add the image to the container
    container.appendChild(img);


}

var tall2 = 100000000

while(tall2<10000000){
    console.log(tall2)

    tall2=tall2 + 1
}

while(0){
    console.log(355/113)
}


console.log("Hi")



    