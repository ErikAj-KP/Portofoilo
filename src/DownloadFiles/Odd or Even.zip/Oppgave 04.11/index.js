var tall = 0;
const tall2 = 0;


tall = tall + 5*2;
console.log(tall)

//tall2 = tall2*2
console.log(tall2) //det vill ikke virke siden du kan ikke endre verdier på const variabler 

var ord1 = "Hei, "
var ord2 = "Oscar"
var ord3 = ord1 + ord2
console.log(ord3)
//jeg tror det kommer til å stå Hei, Oscar



function MinFunksjon(){
    console.log("Hello, World!")
}

MinFunksjon()



function Handleliste(){
    var Melk = 25
    var Brød = 30
    var Brus = 25
    var Spaghetti = 31
    var Ananas = 40

    var sum = Melk + Brød + Brus + Spaghetti + Ananas


    console.log("Handleliste:")
    console.log("Melk",Melk,"Kr")
    console.log("Brød",Brød,"Kr")
    console.log("Brus",Brus,"Kr")
    console.log("Spaghetti",Spaghetti,"Kr")
    console.log("Ananas",Ananas,"Kr")
    
    console.log(sum,"Kr")

}

Handleliste()


//var Add1 = document.getElementById("Num1").innerHTML
//var Add2 =document.getElementById("Num2").innerHTML 

function Addisjon(Add1,Add2){
    return Add1 + Add2 
}


console.log(Addisjon(2,3))

while(false){
    
    if(Num1 >= 0){
        console.log("work")
        break
    }
}
